﻿namespace Tp_Final_PAM1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxExamenPratique = new System.Windows.Forms.TextBox();
            this.textBoxExamenFinal = new System.Windows.Forms.TextBox();
            this.textBoxTP1 = new System.Windows.Forms.TextBox();
            this.textBoxTP2 = new System.Windows.Forms.TextBox();
            this.textBoxTP3 = new System.Windows.Forms.TextBox();
            this.buttonEffacer = new System.Windows.Forms.Button();
            this.buttonQuitter = new System.Windows.Forms.Button();
            this.buttonCalculer = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelNoteGlobale = new System.Windows.Forms.Label();
            this.labelLettre = new System.Windows.Forms.Label();
            this.labelTotalTP = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxExamenPratique
            // 
            this.textBoxExamenPratique.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxExamenPratique.Location = new System.Drawing.Point(435, 122);
            this.textBoxExamenPratique.Multiline = true;
            this.textBoxExamenPratique.Name = "textBoxExamenPratique";
            this.textBoxExamenPratique.Size = new System.Drawing.Size(100, 43);
            this.textBoxExamenPratique.TabIndex = 0;
            this.textBoxExamenPratique.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxExamenFinal
            // 
            this.textBoxExamenFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxExamenFinal.Location = new System.Drawing.Point(435, 240);
            this.textBoxExamenFinal.Multiline = true;
            this.textBoxExamenFinal.Name = "textBoxExamenFinal";
            this.textBoxExamenFinal.Size = new System.Drawing.Size(100, 43);
            this.textBoxExamenFinal.TabIndex = 0;
            this.textBoxExamenFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTP1
            // 
            this.textBoxTP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTP1.Location = new System.Drawing.Point(92, 122);
            this.textBoxTP1.Multiline = true;
            this.textBoxTP1.Name = "textBoxTP1";
            this.textBoxTP1.Size = new System.Drawing.Size(100, 43);
            this.textBoxTP1.TabIndex = 0;
            this.textBoxTP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTP2
            // 
            this.textBoxTP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTP2.Location = new System.Drawing.Point(92, 201);
            this.textBoxTP2.Multiline = true;
            this.textBoxTP2.Name = "textBoxTP2";
            this.textBoxTP2.Size = new System.Drawing.Size(100, 43);
            this.textBoxTP2.TabIndex = 0;
            this.textBoxTP2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxTP3
            // 
            this.textBoxTP3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxTP3.Location = new System.Drawing.Point(92, 280);
            this.textBoxTP3.Multiline = true;
            this.textBoxTP3.Name = "textBoxTP3";
            this.textBoxTP3.Size = new System.Drawing.Size(100, 43);
            this.textBoxTP3.TabIndex = 0;
            this.textBoxTP3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonEffacer
            // 
            this.buttonEffacer.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.buttonEffacer.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonEffacer.Location = new System.Drawing.Point(253, 453);
            this.buttonEffacer.Name = "buttonEffacer";
            this.buttonEffacer.Size = new System.Drawing.Size(104, 29);
            this.buttonEffacer.TabIndex = 1;
            this.buttonEffacer.Text = "Effacer";
            this.buttonEffacer.UseVisualStyleBackColor = false;
            this.buttonEffacer.Click += new System.EventHandler(this.buttonEffacer_Click);
            // 
            // buttonQuitter
            // 
            this.buttonQuitter.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.buttonQuitter.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonQuitter.Location = new System.Drawing.Point(421, 453);
            this.buttonQuitter.Name = "buttonQuitter";
            this.buttonQuitter.Size = new System.Drawing.Size(104, 29);
            this.buttonQuitter.TabIndex = 1;
            this.buttonQuitter.Text = "Quitter";
            this.buttonQuitter.UseVisualStyleBackColor = false;
            this.buttonQuitter.Click += new System.EventHandler(this.buttonQuitter_Click);
            // 
            // buttonCalculer
            // 
            this.buttonCalculer.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.buttonCalculer.Font = new System.Drawing.Font("Elephant", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCalculer.Location = new System.Drawing.Point(92, 453);
            this.buttonCalculer.Name = "buttonCalculer";
            this.buttonCalculer.Size = new System.Drawing.Size(104, 29);
            this.buttonCalculer.TabIndex = 1;
            this.buttonCalculer.Text = "Calculer";
            this.buttonCalculer.UseVisualStyleBackColor = false;
            this.buttonCalculer.Click += new System.EventHandler(this.buttonCalculer_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(289, 139);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "EXAMEN PRATIQUE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(309, 257);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "EXAMEN FINALE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(313, 325);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "NOTE GLOBALE";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(30, 139);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "TP1";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(30, 219);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "TP2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(30, 297);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "TP3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(100, 371);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "TOTAL TP";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(418, 371);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 13);
            this.label9.TabIndex = 2;
            this.label9.Text = "LETTRE A ATTRIBUER";
            // 
            // labelNoteGlobale
            // 
            this.labelNoteGlobale.AutoSize = true;
            this.labelNoteGlobale.Location = new System.Drawing.Point(468, 325);
            this.labelNoteGlobale.Name = "labelNoteGlobale";
            this.labelNoteGlobale.Size = new System.Drawing.Size(13, 13);
            this.labelNoteGlobale.TabIndex = 3;
            this.labelNoteGlobale.Text = "0";
            // 
            // labelLettre
            // 
            this.labelLettre.AutoSize = true;
            this.labelLettre.Location = new System.Drawing.Point(459, 408);
            this.labelLettre.Name = "labelLettre";
            this.labelLettre.Size = new System.Drawing.Size(13, 13);
            this.labelLettre.TabIndex = 3;
            this.labelLettre.Text = "..";
            // 
            // labelTotalTP
            // 
            this.labelTotalTP.AutoSize = true;
            this.labelTotalTP.Location = new System.Drawing.Point(110, 408);
            this.labelTotalTP.Name = "labelTotalTP";
            this.labelTotalTP.Size = new System.Drawing.Size(13, 13);
            this.labelTotalTP.TabIndex = 3;
            this.labelTotalTP.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Wide Latin", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.label8.Location = new System.Drawing.Point(138, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(303, 33);
            this.label8.TabIndex = 4;
            this.label8.Text = "CalculNotes";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 561);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.labelTotalTP);
            this.Controls.Add(this.labelLettre);
            this.Controls.Add(this.labelNoteGlobale);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonQuitter);
            this.Controls.Add(this.buttonCalculer);
            this.Controls.Add(this.buttonEffacer);
            this.Controls.Add(this.textBoxExamenFinal);
            this.Controls.Add(this.textBoxTP3);
            this.Controls.Add(this.textBoxTP2);
            this.Controls.Add(this.textBoxTP1);
            this.Controls.Add(this.textBoxExamenPratique);
            this.Name = "Form1";
            this.Text = "SAISIES DES NOTES TIPAM1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxExamenPratique;
        private System.Windows.Forms.TextBox textBoxExamenFinal;
        private System.Windows.Forms.TextBox textBoxTP1;
        private System.Windows.Forms.TextBox textBoxTP2;
        private System.Windows.Forms.TextBox textBoxTP3;
        private System.Windows.Forms.Button buttonEffacer;
        private System.Windows.Forms.Button buttonQuitter;
        private System.Windows.Forms.Button buttonCalculer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelNoteGlobale;
        private System.Windows.Forms.Label labelLettre;
        private System.Windows.Forms.Label labelTotalTP;
        private System.Windows.Forms.Label label8;
    }
}

