﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tp_Final_PAM1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalculer_Click(object sender, EventArgs e)
        {
            string lettre;
            double tp1, totalTP;
            double tp2;
            double tp3;
            double examenPratique;
            double examenFinal;
            double noteAjusteeTPI,noteGlobale;
            double noteAjusteeTP2, noteAjusteeTP3, noteAjusteeExamenFinal, noteAjusteeExamenPratique;


            if (double.TryParse(textBoxTP1.Text, out tp1) && tp1 >= 0 && tp1 <= 25)
            {
                noteAjusteeTPI = (tp1 / 25) * 20;
                if (double.TryParse(textBoxTP2.Text, out tp2) && tp2 >= 0 && tp2 <= 35)
                {
                    noteAjusteeTP2 = (tp2 / 35) * 20;
                    if (double.TryParse(textBoxTP3.Text, out tp3) && tp3 >= 0 && tp3 <= 40)
                    {
                        noteAjusteeTP3 = (tp3 / 40) * 20;
                        if (double.TryParse(textBoxExamenPratique.Text, out examenPratique) && examenPratique >= 0 && examenPratique <= 100)
                        {
                            noteAjusteeExamenPratique = (examenPratique / 100) * 20;
                            if (double.TryParse(textBoxExamenFinal.Text, out examenFinal) && examenFinal >= 0 && examenFinal <= 100)
                            {
                                noteAjusteeExamenFinal = (examenFinal / 100) * 20;
                                noteGlobale = ((noteAjusteeTPI + noteAjusteeTP2 + noteAjusteeTP3) * 0.4 + noteAjusteeExamenPratique * 0.2 + noteAjusteeExamenFinal * 0.4) / 4;

                                totalTP = noteAjusteeTPI + noteAjusteeTP2 + noteAjusteeTP3;

                                labelNoteGlobale.Text = $"{noteGlobale}";

                                if (noteGlobale > 0 && noteGlobale < 10)
                                    lettre = "E";
                                else if (noteGlobale < 14)
                                    lettre = "D";
                                else if (noteGlobale < 16)
                                    lettre = "C";
                                else if (noteGlobale < 18)
                                    lettre = "B";
                                else
                                    lettre = "A";

                                labelLettre.Text = $"{lettre}";
                                labelTotalTP.Text = $"{totalTP}";


                            }
                            else
                            {
                                MessageBox.Show("Veuillez saisir une note valide pour l'examen final (0-100).", "Erreur de saisie");
                            }

                        }
                        else
                        {
                            MessageBox.Show("Veuillez saisir une note valide pour l'examen pratique (0-100).", "Erreur de saisie");
                        }

                    }
                    else
                    {
                        MessageBox.Show("Veuillez saisir une note valide pour TP3 (0-40).", "Erreur de saisie");
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez saisir une note valide pour TP2 (0-35).", "Erreur de saisie");
                }


            }
            else
            {
                MessageBox.Show("Veuillez saisir une note valide pour TPI (0-25).", "Erreur de saisie");
            }


           






            }

        private void buttonEffacer_Click(object sender, EventArgs e)
        {
            textBoxTP1.Text = "";
            textBoxTP2.Text = "";
            textBoxTP3.Text = "";
            textBoxExamenPratique.Text = "";
            textBoxExamenFinal.Text = "";
            labelNoteGlobale.Text = "";
            labelTotalTP.Text = "";
            labelLettre.Text = "";
        }

        private void buttonQuitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
    }

//®Daniel Hougchi ~Tout droit réservé
